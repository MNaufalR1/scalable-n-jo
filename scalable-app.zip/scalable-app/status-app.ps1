﻿docker-compose ps
Write-Host ""
docker stats --no-stream
