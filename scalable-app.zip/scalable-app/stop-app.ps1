﻿Write-Host "Stopping application..." -ForegroundColor Yellow
docker-compose down
Write-Host "✓ Stopped" -ForegroundColor Green
